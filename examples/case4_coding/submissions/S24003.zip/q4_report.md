# Quadratic formula

**Derivation.** Start from a x^2 + b x + c = 0. Divide by a, then complete the square and we get
the formula

\[ x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a} \]

**Example.** For x^2 - 5x + 6 = 0 the roots are 2 and 3 because 2 times 3 is 6 and 2 plus 3 is 5.

**Discriminant.** It is the part under the root. If it is negative there is no real answer.
