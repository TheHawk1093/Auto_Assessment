def is_palindrome(s):
    # compares the raw text, so spaces and punctuation break it
    return s.lower() == s.lower()[::-1]
