import math


def mean_std(values):
    if not values:
        raise ValueError("no values")
    mean = sum(values) / len(values)
    var = sum((v - mean) ** 2 for v in values) / len(values)
    return mean, math.sqrt(var)
