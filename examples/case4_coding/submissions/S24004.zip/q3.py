def mean_std(values):
    # TODO: work out the mean first, then the spread
    pass
