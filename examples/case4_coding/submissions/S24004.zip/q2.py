def fizzbuzz(n)
    out = []
    for i in range(1, n + 1):
        if i % 15 == 0:
            out.append("FizzBuzz")
        elif i % 3 == 0
            out.append("Fizz")
        else:
            out.append(str(i))
    return out
