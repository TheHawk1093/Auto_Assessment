# Quadratic formula

**Derivation.** Start from a x^2 + b x + c = 0 with a not equal to 0. Divide by a:

\[ x^2 + \frac{b}{a} x + \frac{c}{a} = 0 \]

Move the constant and complete the square by adding \( (b/2a)^2 \) to both sides:

\[ x^2 + \frac{b}{a} x + \frac{b^2}{4a^2} = \frac{b^2}{4a^2} - \frac{c}{a} \]

\[ \left(x + \frac{b}{2a}\right)^2 = \frac{b^2 - 4ac}{4a^2} \]

Taking square roots gives

\[ x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a} \]

**Example.** For x^2 - 5x + 6 = 0, a = 1, b = -5, c = 6, so b^2 - 4ac = 25 - 24 = 1 and
x = (5 +- 1)/2, giving x = 3 or x = 2. Check: 3^2 - 15 + 6 = 0 and 2^2 - 10 + 6 = 0.
