def fizzbuzz(n):
    out = []
    i = 1
    while i <= n:
        if i % 15 == 0:
            out.append("FizzBuzz")
        elif i % 3 == 0:
            out.append("Fizz")
        elif i % 5 == 0:
            out.append("Buzz")
        else:
            out.append(str(i))
        # forgot to add 1 to i
    return out
