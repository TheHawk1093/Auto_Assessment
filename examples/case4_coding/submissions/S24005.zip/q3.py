import math


def mean_std(values):
    mean = sum(values) / len(values)  # ZeroDivisionError for an empty list
    var = sum((v - mean) ** 2 for v in values) / len(values)
    return mean, math.sqrt(var)
